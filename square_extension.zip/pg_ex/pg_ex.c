#include <postgres.h>
#include <executor/spi.h>
#include <utils/geo_decls.h>

PG_MODULE_MAGIC;

Datum square(PG_FUNCTION_ARGS);
PG_FUNCTION_INFO_V1(square);

Datum
square(PG_FUNCTION_ARGS)
{
    int32 arg = PG_GETARG_INT32(0); // Получаем входное значение
    PG_RETURN_INT32(arg * arg);       // Возвращаем квадрат числа
}
