CREATE FUNCTION add_numbers(a integer, b integer)
RETURNS integer
AS 'MODULE_PATHNAME', 'add_numbers'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION subtract_numbers(a integer, b integer)
RETURNS integer
AS 'MODULE_PATHNAME', 'subtract_numbers'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION multiply_numbers(a integer, b integer)
RETURNS integer
AS 'MODULE_PATHNAME', 'multiply_numbers'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION divide_numbers(a integer, b integer)
RETURNS integer
AS 'MODULE_PATHNAME', 'divide_numbers'
LANGUAGE C IMMUTABLE;
