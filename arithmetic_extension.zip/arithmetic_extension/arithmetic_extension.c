
#include <postgres.h>
#include <executor/spi.h>

PG_MODULE_MAGIC;

Datum add_numbers(PG_FUNCTION_ARGS);
Datum subtract_numbers(PG_FUNCTION_ARGS);
Datum multiply_numbers(PG_FUNCTION_ARGS);
Datum divide_numbers(PG_FUNCTION_ARGS);

PG_FUNCTION_INFO_V1(add_numbers);
PG_FUNCTION_INFO_V1(subtract_numbers);
PG_FUNCTION_INFO_V1(multiply_numbers);
PG_FUNCTION_INFO_V1(divide_numbers);

Datum add_numbers(PG_FUNCTION_ARGS)
{
    int32 a = PG_GETARG_INT32(0);
    int32 b = PG_GETARG_INT32(1);
    PG_RETURN_INT32(a + b);
}

Datum subtract_numbers(PG_FUNCTION_ARGS)
{
    int32 a = PG_GETARG_INT32(0);
    int32 b = PG_GETARG_INT32(1);
    PG_RETURN_INT32(a - b);
}

Datum multiply_numbers(PG_FUNCTION_ARGS)
{
    int32 a = PG_GETARG_INT32(0);
    int32 b = PG_GETARG_INT32(1);
    PG_RETURN_INT32(a * b);
}

Datum divide_numbers(PG_FUNCTION_ARGS)
{
    int32 a = PG_GETARG_INT32(0);
    int32 b = PG_GETARG_INT32(1);
    if (b == 0)
        ereport(ERROR, (errmsg("Division by zero")));
    PG_RETURN_INT32(a / b);
}

